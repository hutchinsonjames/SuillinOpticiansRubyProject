var Models = {
  init: function() {
    return console.log("Init Models JS...");
  },


  Search: {
    init: function() {
      console.log("Init Models.Search JS...");
    }, // end of Search.init()

  } // end of Search




};

if (window.Upmin == null) {
  window.Upmin = {};
}

window.Upmin.Models = Models;
